import win32com.client
from datetime import date, timedelta
from write_to_runlog import write_to_runlog

def ClientFlowflag_check():
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")

    subject = 'ClientFlowflag arrived'

    inbox = outlook.GetDefaultFolder(6).Folders('Tidal')
    messages = inbox.Items
    message = messages.GetLast()
    while message:
        if message.senton.date() == date.today():
            if subject.strip() in message.subject.strip():
                try:
                    print('ClientFlowflag has completed at %s' % (message.senton.strftime('%I:%M%p')))
                    # create_todays_runlog()
                    write_to_runlog("Check Tidal/Portfolio Data Services/PATH                                   ",message.senton.strftime('%I:%M%p'))
                    break
                except:
                    print(
                        "An exception Occured in ClientFlowflag check please contact Script Owner,before that make sure to "
                        "check if runlog is open or in use by someone. Make sure to close it")
                    exit()
            else:
                message = messages.GetPrevious()
        else:
            print('ClientFlowflag is not done yet')
            break

#ClientFlowflag_check()