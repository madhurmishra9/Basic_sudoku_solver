import win32com.client
from datetime import date, timedelta
from write_to_runlog import write_to_runlog

def extract_dfa1001_check():
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")

    subject = 'Start and End Time for EXTRACT_DFA1001Completed Normally'

    inbox = outlook.GetDefaultFolder(6).Folders('Tidal')
    messages = inbox.Items
    message = messages.GetLast()
    while message:
        if message.senton.date() == date.today():
            if message.subject.strip() == subject.strip():
                try:
                    print('Extract_DFA1001 has completed at %s' % (message.senton.strftime('%I:%M%p')))
                    # create_todays_runlog()
                    write_to_runlog("""Confirm Tidal job PRD_Sales_Processing / PRD_SASOR / EXTRACT_DFA1001 has completed""",message.senton.strftime('%I:%M%p'))
                    break
                except:
                    print(
                        "An exception Occured in Extract_DFA1001 check please contact Script Owner,before that make sure to check if runlog is open or in use by someone. Make sure to close it")
                    exit()
            else:
                message = messages.GetPrevious()
        else:
            break

#extract_dfa1001_check()