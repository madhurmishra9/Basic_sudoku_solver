import win32com.client
from write_to_runlog import write_to_runlog
import datetime as dt
from send_mail import send_mail

def RunSds2SPDBJobs_check():
    last4HourDateTime = dt.datetime.now() - dt.timedelta(hours=4)
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")

    subject = 'Start and End Time for RunSds2SpdbJobsCompleted Normally'

    inbox = outlook.GetDefaultFolder(6).Folders('Tidal')
    messages = inbox.Items
    messages.Sort("[ReceivedTime]", True)
    last4HourMessages = messages.Restrict("[ReceivedTime] >= '" + last4HourDateTime.strftime('%m/%d/%Y %H:%M%p') + "'")
    message = last4HourMessages.GetFirst()
    count = 0
    while message:
        if message.subject.strip() == subject.strip():
            try:
                print('Portfolio Data Services\Data Warehouse\SDS2SPDB\RunSds2SPDBJobs has completed at %s' % (message.senton.strftime('%I:%M%p')))
                # create_todays_runlog()
                write_to_runlog('Portfolio Data Services\Data Warehouse\SDS2SPDB\RunSds2SPDBJobs ',message.senton.strftime('%I:%M%p'))
                break
            except:
                print(
                    "An exception Occured in RunSds2SPDBJobs_check please contact Script Owner,before that make sure to check if runlog is open or in use by someone. Make sure to close it")
                exit()
        else:
            message = last4HourMessages.GetNext()
            count += 1

    if count == len(last4HourMessages):
        print('RunSds2SPDBJobs is not completed')
        send_mail('mmishra@lordabbett.com','RunSds2SPDBJobs is not completed','Please check subjected job and SDS night cycle status')

#RunSds2SPDBJobs_check()