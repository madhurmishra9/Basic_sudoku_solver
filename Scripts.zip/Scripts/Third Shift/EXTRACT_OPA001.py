import win32com.client
from datetime import date
import openpyxl
import time
import os


def write_to_runlog(tasks='', time_sent_on=''):
    # print('In write_to_runlog')
    filename = 'Third Shift Run Log ' + time.strftime('%m-%d-%Y') + '.xlsx'
    # source = r'L:\Desktop' + '\\' + str(time.strftime('%Y')) + '\\' + str(time.strftime('%m-%B')) + '\\' + 'Third Shift' + '\\' + 'Run Log.xlsx'
    destination = r'L:\Desktop' + '\\' + str(time.strftime('%Y')) + '\\' + str(
        time.strftime('%#m- %B')) + '\\' + "Third Shift" + '\\' + filename
    if os.path.exists(destination):
        wb = openpyxl.load_workbook(destination, read_only=False)
        sheet = wb.active
        # task = "test CHECK"
        time_stamp = time.strftime('%I:%M%p')
        for i in range(1, 100):
            cell = 'B' + str(i)
            if (sheet[cell].value) == tasks:

                time_stamp_cell = 'D' + str(i)
                acr_write_cell = 'E' + str(i)
                sheet[acr_write_cell] = 'MM'
                if time_sent_on != '':  # checking if time is passed an an argument or not
                    # print("Success")
                    # print(sheet[cell].value)
                    sheet[time_stamp_cell] = str(time_sent_on)
                else:
                    sheet[time_stamp_cell] = str(time_stamp)

                wb.save(destination)
                print("Added timestamp as %s and operator signature as %s for %s" % (
                    sheet[time_stamp_cell].value, sheet[acr_write_cell].value, tasks))
                break
    else:
        print("please check as todays runlog is unavailable to update")


def EXTRACT_OPA001_check():
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")

    subject = 'Start and End Time for Batch_EndCompleted Normally'

    inbox = outlook.GetDefaultFolder(6).Folders('Tidal')
    messages = inbox.Items
    message = messages.GetLast()
    while message:
        if message.senton.date() == date.today():
            if message.subject.strip() == subject.strip():
                try:
                    print('EXTRACT_OPA001 has completed at %s' % (message.senton.strftime('%I:%M%p')))
                    # create_todays_runlog()
                    write_to_runlog('EXTRACT_OPA001 ', message.senton.strftime('%I:%M%p'))
                    break
                except:
                    print(
                        "An exception Occured in EXTRACT_OPA001 check please contact Script Owner,before that make sure to "
                        "check if runlog is open or in use by someone. Make sure to close it")
                    exit()
            else:
                message = messages.GetPrevious()
        else:
            print('EXTRACT_OPA001 is not done yet')
            break

#email notiffication is not generated for this job as of now
#EXTRACT_OPA001_check()
