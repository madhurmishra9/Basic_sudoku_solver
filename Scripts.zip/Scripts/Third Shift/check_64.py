import datetime
import time
import os
from write_to_runlog import write_to_runlog


def check_64():
    filenames = ['Summary Report Process Complete.txt', 'Account & Index Comparison Process Complete for Russell', 'Account & Index Comparison Process Complete for SP']
    list_of_avl_files =[]
    count = 0
    for file in os.listdir(r'\\cerap1-ebmv\Apps\Compliance_DM_Jobs\Compliance_Reports_Archive'):
        list_of_avl_files.append(file)
    for i in range (0,3):
        if filenames[i] in list_of_avl_files and time.strftime('%Y-%m-%d', time.localtime(os.path.getmtime(r'\\cerap1-ebmv\Apps\Compliance_DM_Jobs\Compliance_Reports_Archive' + '\\' + filenames[i]))) == str(datetime.date.today()):
            count +=1
        else:
            print('%s file is not arrived yet' % (filenames[i]))

    if count == 3:
        print('All Files are available')
        write_to_runlog("""Summary Report Process Complete.txt
Account & Index Comparison Process Complete for Russell.txt
Account & Index Comparison Process Complete for SP.txt
""",time.strftime('%I:%M%p',time.localtime(os.path.getmtime(r'\\cerap1-ebmv\Apps\Compliance_DM_Jobs\Compliance_Reports_Archive' + '\\' + filenames[0]))))
    #else:
        #return -1


check_64()