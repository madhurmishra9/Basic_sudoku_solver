from datetime import date, timedelta
from write_to_runlog import write_to_runlog
import time
import os

def SSKC_Files():
    date_fl = date.today() - timedelta(days=1)
    date_fl = date_fl.strftime('%Y%m%d') +'.dat.pgp'
    filenames = ['income_','glactivity_','fxactivity_', 'pendfx_', 'slholdings_', 'secmast_', 'glbalances_']
    for i in range(0,len(filenames)):
        filenames[i] = filenames[i] + date_fl

    list_of_avl_files =[]
    count = 0
    for file in os.listdir(r'X:\sskc'):
        list_of_avl_files.append(file)

    for i in range (0,7):
        if filenames[i] in list_of_avl_files:
            count +=1
        else:
            print('%s file is not arrived yet' % (filenames[i]))

    if count == 7:
        #print(time.strftime('%I:%M%p', time.localtime(os.path.getmtime(r'X:\sskc' + '\\' + filenames[0]))))
        write_to_runlog('SSKC Files - (Including GL s/b 7)',time.strftime('%I:%M%p', time.localtime(os.path.getmtime(r'X:\sskc' + '\\' + filenames[0]))))
    else:
        return -1


#SSKC_Files()