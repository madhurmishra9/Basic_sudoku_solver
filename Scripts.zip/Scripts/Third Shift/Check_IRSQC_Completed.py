import win32com.client
import datetime as dt
from write_to_runlog import write_to_runlog
from send_mail import send_mail

def IRSQC_check():
    last4HourDateTime = dt.datetime.now() - dt.timedelta(hours=4)
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")

    subject = 'Start and End Time for IRSQCCompleted Normally'

    inbox = outlook.GetDefaultFolder(6).Folders('Tidal')
    messages = inbox.Items
    messages.Sort("[ReceivedTime]", True)
    last4HourMessages = messages.Restrict("[ReceivedTime] >= '" + last4HourDateTime.strftime('%m/%d/%Y %H:%M%p') + "'")
    # print(len(last4HourMessages))
    message = last4HourMessages.GetFirst()
    count = 0
    while message:
        if message.subject.strip() == subject.strip():
            try:
                print('IRSQC has completed at %s' % (message.senton.strftime('%I:%M%p')))
                # create_todays_runlog()
                write_to_runlog("""CONFIRM IRSQC has completed successfully
 by 2:00AM (This means PATH is complete)""",message.senton.strftime('%I:%M%p'))
                break
            except:
                print(
                        "An exception Occured in IRSQC check please contact Script Owner,before that make sure to check if runlog is open or in use by someone. Make sure to close it")
                exit()
        else:
            message = last4HourMessages.GetNext()
            count += 1
        if count == len(last4HourMessages):
            print('fw_sds_done is not completed')
            send_mail('mmishra@lordabbett.com', 'IRSQC is not completed', 'Please check subjected job and night cycle status')

#IRSQC_check()