from datetime import date, timedelta
from write_to_runlog import write_to_runlog
import time
import os


def Monitor_LA_bofile01_for_nightly_flags():
    if os.path.exists(r'\\LA-bofile01\BOProdStorage\Storage\flags\sasordts_sales.flag') and date.today().strftime('%m-%d-%Y') == time.strftime('%m-%d-%Y', time.localtime(os.path.getmtime(r'\\LA-bofile01\BOProdStorage\Storage\flags\sasordts_sales.flag'))) :
        write_to_runlog('Monitor LA-bofile01 for nightly flags', time.strftime('%I:%M%p', time.localtime(os.path.getmtime(r'\\LA-bofile01\BOProdStorage\Storage\flags\sasordts_sales.flag'))))
        print(time.strftime('%I:%M%p', time.localtime(os.path.getmtime(r'\\ftpclu02-eopp\d$\InetPub\ftproot\EDJones\EDJPR3.TXT'))))
    else:
        print('sasordts_sales.flag not arrived do check if its Holiday or weekend')

#Monitor_LA_bofile01_for_nightly_flags()