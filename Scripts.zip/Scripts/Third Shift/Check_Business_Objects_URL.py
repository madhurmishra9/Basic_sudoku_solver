from write_to_runlog import write_to_runlog
import requests as req
import time


def check_Business_objects_URL():
    #print('In check_la_morningstar_accessibility')
    response = req.get("http://lainfoportal/InfoViewApp/listing/main.do?appKind=InfoView?service=%2FInfoViewApp%2Fcommon%2FappService.do?loc=en")
    #print(response.status_code)
    if response.status_code == 200:
        print("Business Object URL is up and running")
        write_to_runlog('Check Business Objects URL', str(time.strftime('%I:%M%p')))
    else:
        print("Please check as the Business Object URL is unaccessible and have returned %d error"%(response.status_code))

#check_Business_objects_URL()