import win32com.client
from write_to_runlog import write_to_runlog
from datetime import date

def Verify_that_email_is_working_from_smartphone():
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")

    subject = 'Smartphone Email Test'

    inbox = outlook.GetDefaultFolder(6)
    messages = inbox.Items
    message = messages.GetFirst()
    while message:
        if message.senton.date() == date.today():
            if message.subject.strip() == subject.strip():
                try:
                    print('Verify that email is working from smart phone sent at %s' % (message.senton.strftime('%I:%M%p')))
                    # create_todays_runlog()
                    write_to_runlog('Verify that email is working from smart phone',message.senton.strftime('%I:%M%p'))
                    break
                except:
                    print(
                        "An exception Occured in Verify that email is working from smart phone please contact Script Owner,before that make sure to check if runlog is open or in use by someone. Make sure to close it")
                    exit()
            else:
                message = messages.GetNext()
        else:
            break

#Verify_that_email_is_working_from_smartphone()