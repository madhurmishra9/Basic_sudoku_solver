import win32com.client
from write_to_runlog import write_to_runlog
from datetime import date


def Reboot_slx8tcp1_esmv():
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")

    subject = 'Completed Normally REBOOT_SLX8TCP1-ESMV'

    inbox = outlook.GetDefaultFolder(6).Folders['Tidal']
    messages = inbox.Items
    message = messages.GetLast()
    while message:
        if message.senton.date() == date.today():
            if message.subject.strip() == subject.strip():
                try:
                    print('Reboot Reboot slx8tcp1-esmv at %s' %(message.senton.strftime('%I:%M%p')))
                    #create_todays_runlog()
                    write_to_runlog('Reboot slx8tcp1-esmv                           ', message.senton.strftime('%I:%M%p'))
                    break
                except:
                    print("An exception Occured in Reboot slx8tcp1-esmv please contact Script Owner,before that make sure to check if runlog is open or in use by someone. Make sure to close it")
                    exit()
            else:
                message = messages.GetPrevious()
        else:
            break

#Reboot_slx8tcp1_esmv()