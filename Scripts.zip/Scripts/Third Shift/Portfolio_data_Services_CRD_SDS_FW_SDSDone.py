import win32com.client
from write_to_runlog import write_to_runlog
from datetime import date


def fw_sdsdone_check():
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")

    subject = 'Start and End Time for FW_SDSDoneCompleted Normally'

    inbox = outlook.GetDefaultFolder(6).Folders('Tidal')
    messages = inbox.Items
    message = messages.GetLast()
    while message:
        if message.senton.date() == date.today():
            if message.subject.strip() == subject.strip():
                try:
                    print('Portfolio data Services\CRD\SDS\FW_SDSDone has completed at %s' % (message.senton.strftime('%I:%M%p')))
                    # create_todays_runlog()
                    write_to_runlog('Portfolio data Services\CRD\SDS\FW_SDSDone ',message.senton.strftime('%I:%M%p'))
                    break
                except:
                    print(
                        "An exception Occured in fw_sdsdone check please contact Script Owner,before that make sure to check if runlog is open or in use by someone. Make sure to close it")
                    exit()
            else:
                message = messages.GetPrevious()
        else:
            break

#fw_sdsdone_check()