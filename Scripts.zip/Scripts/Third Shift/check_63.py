
import datetime
import time
import os
from write_to_runlog import write_to_runlog


def check_63():
    list_of_avl_files =[]
    count = 0
    verified_date = 0
    string = """CERA Post Trade Compliance-FI2019-01-03-05-25-36.XLS
CERA Post Trade Compliance-EQ2019-01-01-05-27-54.XLS
CERA Surveillance Trades Blotter_prev 2 days2019-01-03-05-25-38.XLS
CERA Surveillance Trades Blotter2019-01-03-05-25-36.XLS
Transaction Review-EQ and FI_2018-12-26-11-27-25.XLS
"""
    for file in os.listdir(r'\\lordabbett.com\nas\Legal and Compliance\Compliance\REGULATORY SURVEILLANCE\Trade Blotters'):
        if file.endswith('XLS'):
            list_of_avl_files.append(file)
    #print(list_of_avl_files)
    count = len(list_of_avl_files)
    #print (count)
    if count != 2:
        print('All files are not yet available')
        #return -1
    else:
        for i in list_of_avl_files:
            if (time.strftime('%Y-%m-%d', time.localtime(os.path.getmtime(r'\\lordabbett.com\nas\Legal and Compliance\Compliance\REGULATORY SURVEILLANCE\Trade Blotters' + '\\' + i)))) == str(datetime.date.today()):
                verified_date += 1
                #print(i)
        if verified_date == 2:
            write_to_runlog(string)
        else:
            print("All files available may not be of current date")



#check_63()