from datetime import date, timedelta
from write_to_runlog import write_to_runlog
import time
import os



def check_BO_reports():
    filenames = ['SMA Drift Heat Map (SCV Unconstrained).pdf','SMA Drift Heat Map (VALOPS Unconstrained).pdf','SMA Drift Heat Map (MS LCV Unconstrained).pdf','SMA Drift Heat Map (MS BALMUN,BALGOV Unconstrained).pdf','SMA Drift Heat Map (MCV Unconstrained).PDF','SMA Drift Heat Map (LCV Unconstrained).pdf','UMA Heat Map (LCV).pdf', 'SMA Drift Heat Map (ACV Unconstrained).pdf', 'SMA Drift Heat Map (BALMUN,BALGOV Unconstrained).PDF', 'SMA Drift Heat Map (INTL Unconstrained).PDF','SMA Muni Assets.pdf']#'SMA Muni Cash Tolerance.pdf']
    #print(len(filenames))
    list_of_avl_files =[]
    count = 0
    no_count = 0
    for file in os.listdir(r'\\la-sma01\DeptData\BOReports'):
        list_of_avl_files.append(file)

    for i in range (0,len(filenames)):
        if filenames[i] in list_of_avl_files and time.strftime('%Y-%m-%d', time.localtime(os.path.getmtime(r'\\la-sma01\DeptData\BOReports' + '\\' + filenames[i])))==str(date.today()):
            count +=1
        else:
            no_count+=1
            print('%s' % (filenames[i]))

    if count == len(filenames):
        write_to_runlog('Check BO Reports',time.strftime('%I:%M%p', time.localtime(os.path.getmtime(r'\\la-sma01\DeptData\BOReports' + '\\' + filenames[10]))))
        #print(time.strftime('%I:%M%p', time.localtime(os.path.getmtime(r'\\la-sma01\DeptData\BOReports' + '\\' + filenames[0]))))
    else:
        print ('%i files not recieved for today'%(no_count))
        return -1



#check_BO_reports()