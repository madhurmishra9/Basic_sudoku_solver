import requests as req
from write_to_runlog import write_to_runlog
import time



def check_la_retirement_planning():
    #print('In check_la_international_site_accessibility')
    response = req.get("https://www.lordabbett.com/en/strategies/retirement-products.html")
    #print(response.status_code)
    if response.status_code == 200:
        write_to_runlog('Verify LA  Retirement PlanVision Web is up and responding (www.lordabbett.com/us/la1/faController)', str(time.strftime('%I:%M%p')))
    else:
        print("Please check as the site is unaccessible and have returned %d error"%(response.status_code))


#check_la_retirement_planning()