import requests as req
from write_to_runlog import write_to_runlog
import time


def check_la_morningstar_accessibility():
    #print('In check_la_morningstar_accessibility')
    response = req.get("https://awrd.morningstar.com/globalhypo/hypo.aspx?fromdocumentwindow=0&dataSource=AWD")
    #print(response.status_code)
    if response.status_code == 200:
        print("Morning star is up and running")
        write_to_runlog('Verify Mutual Fund Hypothetical in Market Intelligence Web site', str(time.strftime('%I:%M%p')))
    else:
        print("Please check as the Morning star site is unaccessible and have returned %d error"%(response.status_code))

#check_la_morningstar_accessibility()