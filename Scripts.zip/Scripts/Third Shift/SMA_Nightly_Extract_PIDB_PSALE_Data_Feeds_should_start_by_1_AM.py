import pandas as pd
from datetime import date, timedelta, datetime
import openpyxl
import time
import os


def write_to_runlog(tasks='', time_sent_on='', time_updated =''):
    #print('In write_to_runlog')
    yst_date = (date.today() - timedelta(1)).strftime('%m-%d-%Y')
    filename = 'Third Shift Run Log ' + yst_date + '.xlsx'
    month = (date.today() - timedelta(1)).strftime('%#m- %B')
    if (date.today() - timedelta(1)).strftime('%m') != (datetime.now()).strftime('%m'):
        month = (date.today() - timedelta(1)).strftime('%#m- %B')
    # source = r'L:\Desktop' + '\\' + str(time.strftime('%Y')) + '\\' + str(time.strftime('%m-%B')) + '\\' + 'First Shift' + '\\' + 'Run Log.xlsx'
    destination = r'L:\Desktop' + '\\' + str(time.strftime('%Y')) + '\\' + month + '\\' + "Third Shift" + '\\' + filename
    if os.path.exists(destination):
        wb = openpyxl.load_workbook(destination, read_only=False)
        sheet = wb.active
        # task = "test CHECK"
        time_stamp = time.strftime('%I:%M%p')
        for i in range(1, 50):
            cell = 'B' + str(i)
            if (sheet[cell].value) == tasks:

                time_stamp_cell = 'D' + str(i)
                acr_write_cell = 'E' + str(i)
                acr_write_data = 'F' + str(i)
                sheet[acr_write_cell] = 'Auto'
                if time_sent_on != '':  # checking if time is passed an an argument or not
                    # print("Success")
                    # print(sheet[cell].value)
                    sheet[time_stamp_cell] = str(time_sent_on)
                    sheet[acr_write_data] = time_updated
                else:
                    sheet[time_stamp_cell] = str(time_stamp)
                    sheet[acr_write_data] = time_updated

                wb.save(destination)
                print("Added timestamp as %s and operator signature as %s for %s" % (
                sheet[time_stamp_cell].value, sheet[acr_write_cell].value, tasks))
                break
    else:
        print("please check as todays runlog is unavailable to update")

def check_SMA_Feeds():
    #url = r'http://pdsbatp1-eiov/warehouse/cgi-bin/datafeeds.pl'
    #r = requests.get(url)
    tables = pd.read_html('http://pdsbatp1-eiov/warehouse/cgi-bin/datafeeds.pl', skiprows=12, header = 0)[0].head(1)
    #print(tables)
    row_list= []
    for i in tables:
        row_list.append(i)
    #print(row_list)
    if row_list[3] == '17.1':
        print('SMA Nightly Extract feeds are updated')
        write_to_runlog('SMA Nightly Extract  (PIDB/PSALE Data Feeds) should start by 1 AM ', time_updated=row_list[7])
    else:
        print('SMA Nightly Extract feeds are yet to update')

#check_SMA_Feeds()