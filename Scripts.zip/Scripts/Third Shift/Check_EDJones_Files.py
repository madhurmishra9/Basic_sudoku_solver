from datetime import date, timedelta
from write_to_runlog import write_to_runlog
import time
import os


def check_EDJones_time():
    if os.path.exists(r'\\ftpclu02-eopp\d$\InetPub\ftproot\EDJones\EDJPR3.TXT') and date.today().strftime('%m-%d-%Y') == time.strftime('%m-%d-%Y', time.localtime(os.path.getmtime(r'\\ftpclu02-eopp\d$\InetPub\ftproot\EDJones\EDJPR3.TXT'))) :
        write_to_runlog('Check EDJones Files', time.strftime('%I:%M%p', time.localtime(os.path.getmtime(r'\\ftpclu02-eopp\d$\InetPub\ftproot\EDJones\EDJPR3.TXT'))))
        print(time.strftime('%I:%M%p', time.localtime(os.path.getmtime(r'\\ftpclu02-eopp\d$\InetPub\ftproot\EDJones\EDJPR3.TXT'))))
    else:
        print('EDJPR3.TXT file not arrived do check if its Holiday or weekend')

#check_EDJones_time()