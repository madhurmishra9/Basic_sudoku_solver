import pyautogui
import time

while True:
    pyautogui.press('volumedown')
    time.sleep(120)
    pyautogui.press('volumeup')
    time.sleep(240)