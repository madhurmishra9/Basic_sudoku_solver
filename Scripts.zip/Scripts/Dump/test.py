from datetime import date, timedelta, datetime
import calendar


yst_date = (date.today() - timedelta(1)).strftime('%m')
print(type(yst_date))
month = (datetime.now()).strftime('%m')
print(type(month))