
from selenium import webdriver

#for mozilla
#from selenium import webdriver
browser = webdriver.Firefox(executable_path=r'C:\Users\MMISHRA\Downloads\geckodriver.exe')
browser.get('http://tidalcmp1-eopv:8080/client/console.html?locale=en')
browser.find_element_by_id('USERNAME_PROPERTY').send_keys('lord_abbett\mmishra')
browser.find_element_by_id ('PASSWORD_PROPERTY').send_keys('Ram@12345')
browser.find_element_by_id('ok').click()