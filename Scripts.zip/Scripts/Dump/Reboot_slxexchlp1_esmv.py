import win32com.client
from write_to_runlog import write_to_runlog
from datetime import date


def Reboot_slxexchlp1_esmv():
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")

    subject = 'Completed Normally REBOOT SLXEXCHLP1-ESMV'

    inbox = outlook.GetDefaultFolder(6).Folders['Tidal']
    messages = inbox.Items
    message = messages.GetLast()
    while message:
        if message.senton.date() == date.today():
            if message.subject.strip() == subject.strip():
                try:
                    print('Reboot slxexchlp1-esmv completed at %s' %(message.senton.strftime('%I:%M%p')))
                    #create_todays_runlog()
                    write_to_runlog('Reboot slxexchlp1-esmv                           ', message.senton.strftime('%I:%M%p'))
                    break
                except:
                    print("An exception Occured in Reboot slxexchlp1-esmv please contact Script Owner,before that make sure to check if runlog is open or in use by someone. Make sure to close it")
                    exit()
            else:
                message = messages.GetPrevious()
        else:
            break


#Reboot_slxexchlp1_esmv()