import win32com.client
from datetime import date
import os


def failed_job_check():
    os.system("tzutil /s \"Eastern Standard Time\"")
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")

    inbox = outlook.GetDefaultFolder(6)
    messages = inbox.Items
    message = messages.GetLast()
    while message:
        if message.senton.date() == date.today():
            if('completed abnormally' in (message.subject.strip()).lower()) and (not ((message.subject.strip()).lower()).startswith('re') or (((message.subject.strip()).lower()).startswith('fw'))):
                try:
                    print(((((message.subject).lower()).replace('completed abnormally','')).strip(' - ')).strip('--->'))
                except:
                    print('Something went wrong while manipulating string')
                    exit()

            message = messages.GetPrevious()
        else:
            break

failed_job_check()