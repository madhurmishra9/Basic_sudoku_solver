import win32com.client
from datetime import date
from write_to_runlog import write_to_runlog
import time


def netbackup_failure_report_copy_paste():
    #print('In netbackup_failure_report_copy_paste')
    today = date.today()
    today_date = today.strftime("%m-%d-%y")
    path = r'L:\Desktop'
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")# this will tell windows to open a outlook client
    accounts = win32com.client.Dispatch("Outlook.Application").Session.Accounts # will generate a session

    email_subject = "Previous Day NBU Backup Failures"
    #tasks = r'Save  Previous Day NBU Backup Failures report to NetBackup Document and Catalog Backup
    #\\la-fp02\IT Operations\NCC\Documentation\NCC-SOP\NetBackup_Docs\NBU Documentation'

    inbox = outlook.GetDefaultFolder(6).Folders['Netbackup']#here the default folder 6 -> stands for inbox and .folders is used to find the sub folder
    messages = inbox.Items #this will fetch all emails into a list like object
    message = messages.GetFirst()#will select the first email from the emails stored in list object
    #below logic will serach all emails one by one until if finds the very first instance of the latest email subject
    while message:
        if message.senton.date() == date.today():
            if message.subject == email_subject:
                msgname = str(message.subject)
                try:
                    write_to_runlog(r"""Save  Previous Day NBU Backup Failures report to NetBackup Document and Catalog Backup
\\la-fp02\IT Operations\NCC\Documentation\NCC-SOP\NetBackup_Docs\NBU Documentation""", time.strftime('%I:%M%p'))
                    write_to_runlog("""Check Previous Day NBU Failures Report. 
report issues""", str((message.senton).strftime('%I:%M%p')))
                    message.saveas(path + '\\' + msgname + str(today_date) + '.msg')
                    print("Netbackup Failure report Email copied succesfully")
                    break
                except:
                    print("An exception Occured in netbackup_failure_report_copy_paste() please contact Script Owner, before that make sure to check if runlog is open or in use by someone. Make sure to close it")
                    exit()
            else:
                message = messages.GetNext()#if the subject doesn't matches to the one which we need to copy it will move to the next message in sequesnce
        else:
            break


#netbackup_failure_report_copy_paste()