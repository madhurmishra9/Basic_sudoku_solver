import win32com.client
from datetime import date
from write_to_runlog import write_to_runlog
import time


def netbackup_catalog_email_copy_paste():
    #print('In netbackup_catalog_email_copy_paste')
    today = date.today()
    today_date = today.strftime("%m-%d-%y")
    path = r'L:\Desktop'
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
    accounts = win32com.client.Dispatch("Outlook.Application").Session.Accounts

    email_subject = "NetBackup Catalog Backup successful on host nbumastp1-eopp.lordabbett.com status 0"
    task = r"""Save NetBackup Catalog Backup email to folder 
\\la-fp02\IT Operations\NCC\Documentation\NCC-SOP\NetBackup_Docs\NBU Documentation"""

    inbox = outlook.GetDefaultFolder(6).Folders['Netbackup']
    messages = inbox.Items
    message = messages.GetFirst()

    while message:
        if message.senton.date() == date.today():
            if message.subject == email_subject:
                msgname = str(message.subject)
                try:
                    message.saveas(path + '\\' + msgname + str(today_date) + '.msg')
                    write_to_runlog(task, time.strftime('%I:%M%p'))
                    print("Netbackup Catalog email copied succesfully")
                    break
                except:
                    print("An exception Occured in netbackup_catalog_email_copy_paste() please contact Script Owner")
                    exit()
            else:
                message = messages.GetNext()
        else:
            break

#netbackup_catalog_email_copy_paste()