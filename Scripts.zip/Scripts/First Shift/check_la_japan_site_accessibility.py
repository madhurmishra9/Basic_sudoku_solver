import requests as req
from write_to_runlog import write_to_runlog

def check_la_japan_site_accessibility():
    print('In check_la_japan_site_accessibility')
    response = req.get("https://www.lordabbett.co.jp/ja.html")
    # print(response.status_code)
    if response.status_code == 200:  # will check if response is 200 that means the website is accessible
        print("Lord Abbett Japan site is up and running")
        #write_to_runlog( , str(time.strftime('%I:%M%p')))
    else:
        print("Please check as the site is unaccessible and have returned %d error" % (response.status_code))


#check_la_japan_site_accessibility()