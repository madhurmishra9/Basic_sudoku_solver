import win32com.client
from datetime import date
from write_to_runlog import write_to_runlog

def check_3704_HR_email_recieve_time():
    #print('In check_3704_HR_email_recieve_time')
    today = date.today()
    today_date = today.strftime("%m-%d-%y")
    path = r'L:\Desktop'
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
    accounts = win32com.client.Dispatch("Outlook.Application").Session.Accounts

    subject = "ConnectEMC notification from APM00083103704 (HR)"

    inbox = outlook.GetDefaultFolder(6).Folders['Prod_Storage']
    messages = inbox.Items
    message = messages.GetFirst()
    while message:
        if message.senton.date() == date.today():
            if message.subject.strip() == subject.strip():#.strip is used to shrink or strip any extra sapace found in the subject of the mail
                try:
                    print("Centera Health Report 3704: %s" %(message.senton))#message.senton will give give us the time of email recieved
                    write_to_runlog('Centera Health Report 3704',str((message.senton).strftime('%I:%M%p')))
                    break
                except:
                    print("An exception Occured in check_3704_HR_email_recieve_time() please contact Script Owner,before that make sure to check if runlog is open or in use by someone. Make sure to close it")
                    exit()
            else:
                message = messages.GetNext()
        else:
            break

#check_3704_HR_email_recieve_time()