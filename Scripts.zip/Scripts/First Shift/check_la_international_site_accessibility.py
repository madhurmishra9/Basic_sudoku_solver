import requests as req
from write_to_runlog import write_to_runlog
import time



def check_la_international_site_accessibility():
    print('In check_la_international_site_accessibility')
    response = req.get("https://www.lordabbett.com/en.html")
    #print(response.status_code)
    if response.status_code == 200:
        print("Lord Abbett MorningStar is up and running")
        write_to_runlog('Verify www.lordabbett.com website', str(time.strftime('%I:%M%p')))
    else:
        print("Please check as the site is unaccessible and have returned %d error"%(response.status_code))


#check_la_international_site_accessibility()