import win32com.client
from datetime import date
from write_to_runlog import write_to_runlog

def check_dd4500p1_email_recieve_time():
    #print('In check_dd4500p1_email_recieve_time')
    today = date.today()
    today_date = today.strftime("%m-%d-%y")
    path = r'L:\Desktop'
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
    accounts = win32com.client.Dispatch("Outlook.Application").Session.Accounts

    subject = r'scheduled autosupport (dd4500p1-veth0.lordabbett.com)'

    inbox = outlook.GetDefaultFolder(6).Folders['Netbackup']
    messages = inbox.Items
    message = messages.GetFirst()
    while message:
        if message.senton.date() == date.today():
            if message.subject.strip() == subject.strip():
                try:
                    print("Data Domain : usage dd4500p1: %s" %(message.senton).strftime('%I:%M%p'))
                    create_todays_runlog()
                    write_to_runlog("Data Domain : usage dd4500p1",str((message.senton).strftime('%I:%M%p')))
                    break
                except:
                    print("An exception Occured in check_dd4500p1_email_recieve_time() please contact Script Owner,before that make sure to check if runlog is open or in use by someone. Make sure to close it")
                    exit()
            else:
                message = messages.GetNext()
        else:
            break


#check_dd4500p1_email_recieve_time()