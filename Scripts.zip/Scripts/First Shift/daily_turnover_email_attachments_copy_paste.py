import win32com.client
from datetime import date
import openpyxl
import time
import os

def write_to_runlog(tasks='', time_sent_on=''):
    #print('In write_to_runlog')
    filename = 'Run Log ' + time.strftime('%m-%d-%Y') + '.xlsx'
    # source = r'L:\Desktop' + '\\' + str(time.strftime('%Y')) + '\\' + str(time.strftime('%m-%B')) + '\\' + 'First Shift' + '\\' + 'Run Log.xlsx'
    destination = r'L:\Desktop' + '\\' + str(time.strftime('%Y')) + '\\' + str(time.strftime('%#m- %B')) + '\\' + "First Shift" + '\\' + filename
    if os.path.exists(destination):
        wb = openpyxl.load_workbook(destination, read_only=False)
        sheet = wb.active
        # task = "test CHECK"
        time_stamp = time.strftime('%I:%M%p')
        for i in range(1, 50):
            cell = 'B' + str(i)
            if (sheet[cell].value) == tasks:
                time_stamp_cell = 'D' + str(i)
                acr_write_cell = 'E' + str(i)
                sheet[acr_write_cell] = 'MM'
                if time_sent_on != '':  # checking if time is passed an an argument or not
                    # print("Success")
                    # print(sheet[cell].value)
                    sheet[time_stamp_cell] = str(time_sent_on)
                else:
                    sheet[time_stamp_cell] = str(time_stamp)

                wb.save(destination)
                print("Added timestamp as %s and operator signature as %s for %s" % (
                sheet[time_stamp_cell].value, sheet[acr_write_cell].value, tasks))
                break
    else:
        print("please check as todays runlog is unavailable for update")


def daily_turnover_email_attachments_copy_paste():
    #print('In daily_turnover_email_attachments_copy_paste')
    today = date.today()
    today_date = today.strftime("%m-%d-%y")
    path = r'L:\Desktop'
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
    accounts = win32com.client.Dispatch("Outlook.Application").Session.Accounts

    email_subject = "Daily Turnover Report"

    inbox = outlook.GetDefaultFolder(6)
    messages = inbox.Items
    message = messages.GetFirst()
    while message:
        if message.senton.date() == date.today():
            if email_subject in message.subject:
                msgname = str(message.subject)
                print(msgname)
                try:
                    attachments = message.Attachments.Item(1)
                    attachments.SaveASFile(
                        os.getcwd() + '\\' + str(attachments))  # Saves to the attachment to current folder
                    print(attachments)
                except Exception as e:
                    print(e)
                    print(
                        "An exception Occured in daily_turnover_email_attachments_copy_pastedaily_turnover_email_attachments_copy_paste, please close runlog or contact Script Owner")
                    exit()
            else:
                break
            message = messages.GetNext()
        else:
            break

    inbox = outlook.GetDefaultFolder(6).Folders['Service_Now']
    email_subject = 'Turnover Report - IT Operations'
    messages = inbox.Items
    message = messages.GetFirst()
    while message:
        if message.senton.date() == date.today():
            if email_subject in message.subject:
                msgname = str(message.subject)
                print(msgname)
                try:
                    for i in 2, 3:
                        attachments = message.Attachments.Item(i)
                        attachments.SaveASFile(
                            os.getcwd() + '\\' + str(attachments))  # Saves to the attachment to current folder
                        print(attachments)
                except Exception as e:
                    print(e)
                    print(
                        "An exception Occured in daily_turnover_email_attachments_copy_pastedaily_turnover_email_attachments_copy_paste, please close runlog or contact Script Owner")
                    exit()
            else:
                break
            message = messages.GetNext()
        else:
            break


#daily_turnover_email_attachments_copy_paste()