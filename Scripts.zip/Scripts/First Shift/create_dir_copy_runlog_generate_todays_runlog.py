from datetime import date, timedelta
import shutil
import time
import os


def create_todays_runlog():
    #print('In create_todays_runlog')
    #create_or_check_dir()
    filename = 'Run Log ' + time.strftime('%m-%d-%Y') + '.xlsx'
    source = r'L:\Desktop' + '\\' + str(time.strftime('%Y')) + '\\' + str(time.strftime('%#m- %B')) + '\\' + 'First Shift' + '\\' + 'Run Log.xlsx'
    destination = r'L:\Desktop' + '\\' + str(time.strftime('%Y')) + '\\' + str(time.strftime('%#m- %B')) + '\\' + "First Shift" + '\\' + filename
    if not os.path.exists(destination):
        shutil.copy(source,destination)# used to copy a file with different name
        print("Todays runlog created")
    else:
        print("Todays runlog exists")

def copy_generic_rulog_template():#the function will check if the Runlog template is copied or not , this will run on the first of every month
    #print('In copy_generic_runlog_template')
    if not os.path.exists(r'L:\Desktop' + '\\' + str(time.strftime('%Y')) + '\\' + str(time.strftime('%#m- %B')) + '\\' + 'First Shift' + '\\' + 'Run Log.xlsx' ):
                first_day_of_this_month = date.today().replace(day=1)
                last_day_prev_month = first_day_of_this_month - timedelta(days=1)
                prev_month_name = last_day_prev_month.strftime('%#m- %B')
                path = r'\\la-fp06\IT Operations\NCC\Logs\Run-logs' + '\\' + str(time.strftime('%Y'))
                source = path + '\\' + prev_month_name + '\\' + 'First Shift' + '\\' + 'Run Log.xlsx'
                destination = r'L:\Desktop' + '\\' + str(time.strftime('%Y')) + '\\' + str(time.strftime('%#m- %B')) + '\\' + "First Shift"
                shutil.copy(source,destination)
                print ("Generic First Shift Run Log.xlsx template copied")
                create_todays_runlog()
                return
    else:
        print("runlog template exists")
        create_todays_runlog()
        return

def create_or_check_dir():
    #print('In create_or_check_dir')
    if not os.path.exists(r'L:\Desktop' + '\\' + str(time.strftime('%Y'))):
        os.mkdir(r'L:\Desktop' + '\\' + str(time.strftime('%Y')))
        if not os.path.exists(r'L:\Desktop' + '\\' + str(time.strftime('%Y')) + '\\' + str(time.strftime('%#m- %B'))):
            os.mkdir(r'L:\Desktop' + '\\' + str(time.strftime('%Y')) + '\\' + str(time.strftime('%#m- %B')))
            #print(os.path.exists(r'L:\Desktop' + '\\' + str(time.strftime('%Y')) + '\\' + str(time.strftime('%#m- %B')) + 'First Shift'))
            if not os.path.exists(r'L:\Desktop' + '\\' + str(time.strftime('%Y')) + '\\' + str(time.strftime('%#m- %B')) + 'First Shift'):
                #print('In here')
                os.mkdir(r'L:\Desktop' + '\\' + str(time.strftime('%Y')) + '\\' + str(time.strftime('%#m- %B')) + '\\' + 'First Shift')
                copy_generic_rulog_template()
                return
    elif not os.path.exists(r'L:\Desktop' + '\\' + str(time.strftime('%Y')) + '\\' + str(time.strftime('%#m- %B'))):
        os.mkdir(r'L:\Desktop' + '\\' + str(time.strftime('%Y')) + '\\' + str(time.strftime('%#m- %B')))
        if not os.path.exists(r'L:\Desktop' + '\\' + str(time.strftime('%Y')) + '\\' + str(time.strftime('%#m- %B')) + 'First Shift'):
            os.mkdir(r'L:\Desktop' + '\\' + str(time.strftime('%Y')) + '\\' + str(time.strftime('%#m- %B')) + '\\' + 'First Shift')
            copy_generic_rulog_template()
            return
    elif not os.path.exists(r'L:\Desktop' + '\\' + str(time.strftime('%Y')) + '\\' + str(time.strftime('%#m- %B')) + 'First Shift'):
        try:
            os.mkdir(r'L:\Desktop' + '\\' + str(time.strftime('%Y')) + '\\' + str(time.strftime('%#m- %B')) + '\\' + 'First Shift')
            copy_generic_rulog_template()
            return
        except:
            print("First Shift folder exists, Copying First Shift Run Log.xlsx")
            copy_generic_rulog_template()
            return


#create_or_check_dir()

