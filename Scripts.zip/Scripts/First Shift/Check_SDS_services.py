import requests

req = requests.get('http://lxnagxip3-eopv/nagiosxi/api/v1/config/service?apikey=4nEqnjmQm3VJt97rYpSWuRXKVPDoFhDYXeplA5rV7mUTPil4KtZuEdfA2ReW8QVm&service_description=SmfRequestProcessor.sh&service_description=SmfRequestProcessorSAS.sh&combiner=or&match=search&check=true')
print(req.json())