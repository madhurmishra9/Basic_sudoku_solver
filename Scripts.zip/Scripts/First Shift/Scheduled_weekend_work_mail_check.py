import win32com.client
from datetime import date
from write_to_runlog import write_to_runlog

def Scheduled_Weekend_Work_mail_check():
    #print('In Scheduled_Weekend_Work_mail_check')
    today = date.today()
    today_date = today.strftime("%m-%d-%y")
    path = r'L:\Desktop'
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
    accounts = win32com.client.Dispatch("Outlook.Application").Session.Accounts

    subject = r'Scheduled Weekend Work'

    inbox = outlook.GetDefaultFolder(6).Folders['Service_Now']
    messages = inbox.Items
    message = messages.GetFirst()

    while message:
        if message.senton.date() == date.today() and message.subject.strip() == subject.strip() and (today.strftime(
                '%A') == 'Friday' or today.strftime('%A') == 'Monday'):
            print("")
            try:
                #create_todays_runlog()
                print('Verify Scheduled Work Report to IT Infrastructure Managers and ITO(Fridays) message at:%s' %(message.senton).strftime('%I:%M%p'))
                write_to_runlog('Verify Scheduled Work Report to IT Infrastructure Managers and ITO(Fridays)',str((message.senton).strftime('%I:%M%p')))
                break
            except:
                print(
                    "An exception Occured in Scheduled_Weekend_Work_mail_check() please contact Script Owner, before that make sure to check if runlog is open or in use by someone. Make sure to close it")
                exit()

        else:
            # send_mail()
            print ("It's Not Monday or Friday Today!! :(")
            break
        message = messages.GetNext()

#Scheduled_Weekend_Work_mail_check()