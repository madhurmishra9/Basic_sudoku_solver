import win32com.client
from datetime import date
from write_to_runlog import write_to_runlog
import time


def VRI_email_copy_paste():
    #print('In VRI_email_copy_paste')
    today = date.today()
    today_date = today.strftime("%m-%d-%y")
    path = r'L:\Desktop'
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
    accounts = win32com.client.Dispatch("Outlook.Application").Session.Accounts

    email_subject = "Vital Records, Inc. Account 003865 Information received"
    task = r"""Move email from VRI to Netbackup folder under VRI Tape Logs=> 2017 VRI Tape Logs"""

    inbox = outlook.GetDefaultFolder(6).Folders['Vital Records']
    messages = inbox.Items
    message = messages.GetFirst()
    while message:
        if message.senton.date() == date.today():
            if email_subject in message.subject:
                msgname = str(message.subject)
                try:
                    message.saveas(path + '\\' + msgname + '.msg')
                    write_to_runlog(task, time.strftime('%I:%M%p'))
                    write_to_runlog(
                        'Check for email from donotreply@vitalrecords.com as confirmation that tapes have been entered into VRI Web Portal ',
                        str((message.senton).strftime('%I:%M%p')))
                    write_to_runlog(
                        r'UpdateTape Inventory log (if scratch are added from our inventory: \\la-fp02\IT Operations\NCC\Documentation\NCC-SOP\NetBackup_Docs\VRI Tape Logs\2018 VRI Tapes Logs',
                        time.strftime('%I:%M%p'))
                    print("VRI email copied succesfully")

                except Exception as e:
                    print(e)
                    # print("An exception Occured in VRI_email_copy_paste please contact Script Owner")
                    # exit()
            else:
                pass
            message = messages.GetNext()
        else:
            write_to_runlog(task, time.strftime('%I:%M%p'))
            write_to_runlog(
                'Check for email from donotreply@vitalrecords.com as confirmation that tapes have been entered into VRI Web Portal ',
                time.strftime('%I:%M%p'))
            write_to_runlog(
                r'UpdateTape Inventory log (if scratch are added from our inventory: \\la-fp02\IT Operations\NCC\Documentation\NCC-SOP\NetBackup_Docs\VRI Tape Logs\2018 VRI Tapes Logs',
                str((message.senton).strftime('%I:%M%p')))
            break

#VRI_email_copy_paste()