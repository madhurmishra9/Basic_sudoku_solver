import win32com.client
from datetime import date
from write_to_runlog import write_to_runlog

def CE_EXTRACTS_check():
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")

    subject = 'Start and End Time for CE_EXTRACTSCompleted Normally'

    inbox = outlook.GetDefaultFolder(6).Folders('Tidal')
    messages = inbox.Items
    message = messages.GetLast()
    while message:
        if message.senton.date() == date.today():
            if message.subject.strip() == subject.strip():
                try:
                    print('CE_EXTRACTS has completed at %s' % (message.senton.strftime('%I:%M%p')))
                    # create_todays_runlog()
                    write_to_runlog("Make sure this job is done.(Accounting Technology -0-SimCorp -Client Extracts-CE_EXTRACTS)",message.senton.strftime('%I:%M%p'))
                    break
                except:
                    print(
                        "An exception Occured in CE_EXTRACTS please contact Script Owner,before that make sure to check if runlog is open or in use by someone. Make sure to close it")
                    exit()
            else:
                message = messages.GetPrevious()
        else:
            break

#CE_EXTRACTS_check()