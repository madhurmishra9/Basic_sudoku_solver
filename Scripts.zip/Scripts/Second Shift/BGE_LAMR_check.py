import win32com.client
from datetime import date
from write_to_runlog import write_to_runlog

def BGE_LAMR_check():
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")

    subject = 'Start and End Time for BGE_LAMRCompleted Normally'

    inbox = outlook.GetDefaultFolder(6).Folders('Tidal')
    messages = inbox.Items
    message = messages.GetLast()
    while message:
        if message.senton.date() == date.today():
            if message.subject.strip() == subject.strip():
                try:
                    print('BGE_LAMR has completed at %s' % (message.senton.strftime('%I:%M%p')))
                    # create_todays_runlog()
                    write_to_runlog("Completion time of Equity Load = Job BGE_LAMR (Update IT Ops Turnover Report)",message.senton.strftime('%I:%M%p'))
                    break
                except:
                    print(
                        "An exception Occured in BGE_LAMR please contact Script Owner,before that make sure to check if runlog is open or in use by someone. Make sure to close it")
                    exit()
            else:
                message = messages.GetPrevious()
        else:
            break

#BGE_LAMR_check()