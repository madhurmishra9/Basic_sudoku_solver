import win32com.client
from datetime import date
from write_to_runlog import write_to_runlog

def FW_Isl1Done_check():
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")

    subject = 'Start and End Time for FW_Isl1DoneCompleted Normally'

    inbox = outlook.GetDefaultFolder(6).Folders('Tidal')
    messages = inbox.Items
    message = messages.GetLast()
    while message:
        if message.senton.date() == date.today():
            if message.subject.strip() == subject.strip():
                try:
                    print('FW_Isl1Done has completed at %s' % (message.senton.strftime('%I:%M%p')))
                    # create_todays_runlog()
                    write_to_runlog("Completion time of Benchmark Data Load = Job FW_Isl1Done (Update IT Ops Turnover Report) SDS",message.senton.strftime('%I:%M%p'))
                    break
                except:
                    print(
                        "An exception Occured in FW_Isl1Done check please contact Script Owner,before that make sure to check if runlog is open or in use by someone. Make sure to close it")
                    exit()
            else:
                message = messages.GetPrevious()
        else:
            break

#FW_Isl1Done_check()