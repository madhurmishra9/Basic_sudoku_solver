import win32com.client
from datetime import date
from write_to_runlog import write_to_runlog

def Pricing_is_complete_check():
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")

    subject = 'Pricing is complete'

    inbox = outlook.GetDefaultFolder(6)
    messages = inbox.Items
    message = messages.GetLast()
    while message:
        if message.senton.date() == date.today():
            if message.subject.strip() == subject.strip():
                try:
                    print('Pricing is complete has completed at %s' % (message.senton.strftime('%I:%M%p')))
                    # create_todays_runlog()
                    write_to_runlog("Pricing is complete",message.senton.strftime('%I:%M%p'))
                    break
                except:
                    print(
                        "An exception Occured in Pricing is complete check please contact Script Owner,before that make sure to check if runlog is open or in use by someone. Make sure to close it")
                    exit()
            else:
                message = messages.GetPrevious()
        else:
            break

#Pricing_is_complete_check()