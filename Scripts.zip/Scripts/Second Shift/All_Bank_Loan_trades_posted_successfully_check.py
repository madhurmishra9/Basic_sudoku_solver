import win32com.client
from datetime import date
from write_to_runlog import write_to_runlog
from send_mail import send_mail

def Bank_Loan_trades_posted_check():
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")

    subject = 'All Bank Loan trades posted successfully'

    inbox = outlook.GetDefaultFolder(6)
    messages = inbox.Items
    message = messages.GetLast()
    #print(message.subject)
    while message:
        if message.senton.date() == date.today():
            #print(message.subject)
            if (message.subject.strip()).lower() == (subject.strip()).lower():
                try:
                    print('All Bank Loan trades posted successfully has completed at %s' % (message.senton.strftime('%I:%M%p')))
                    write_to_runlog("All Bank Loan trades posted successfully",message.senton.strftime('%I:%M%p'))
                    break
                except:
                    print("An exception Occured in All Bank Loan trades posted successfully check please contact Script Owner,before that make sure to check if runlog is open or in use by someone. Make sure to close it")
                    exit()
            else:
                message = messages.GetPrevious()
        else:
            if message.senton.date != date.today():
                #print('Swift email not received')
                message_body = 'Team please confirm whether All Bank Loan trades posted successfully'
                send_mail('mmishra@lordabbett.com','Not received All Bank Loan trades posted successfully',message_body,)
                #exit(-1)
                break


#Bank_Loan_trades_posted_check()