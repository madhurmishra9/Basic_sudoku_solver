import win32com.client
from datetime import date
from write_to_runlog import write_to_runlog

def Place_SDI_onhold_check():
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")

    subject = '010_Begin_Night_Cycle has started.  Place SDI group on HOLD'

    inbox = outlook.GetDefaultFolder(6).Folders('Tidal')
    messages = inbox.Items
    message = messages.GetLast()
    while message:
        if message.senton.date() == date.today():
            if message.subject.strip() == subject.strip():
                try:
                    print('Put sdi on hold message arrived at %s' % (message.senton.strftime('%I:%M%p')))
                    # create_todays_runlog()
                    write_to_runlog("Before you start SCD End of Day Complete PUT THE SDI GROUP  ON HOLD",message.senton.strftime('%I:%M%p'))
                    break
                except:
                    print(
                        "An exception Occured in place SDI check please contact Script Owner,before that make sure to check if runlog is open or in use by someone. Make sure to close it")
                    exit()
            else:
                message = messages.GetPrevious()
        else:
            break

Place_SDI_onhold_check()