import openpyxl
import time
import os

def write_to_runlog(tasks='', time_sent_on=''):
    #print('In write_to_runlog')
    filename = 'Second Shift Run Log SimCorp ' + time.strftime('%m-%d-%Y') + '.xlsx'
    # source = r'L:\Desktop' + '\\' + str(time.strftime('%Y')) + '\\' + str(time.strftime('%m-%B')) + '\\' + 'Third Shift' + '\\' + 'Run Log.xlsx'
    destination = r'L:\Desktop' + '\\' + str(time.strftime('%Y')) + '\\' + str(
        time.strftime('%#m- %B')) + '\\' + "Second Shift" + '\\' + filename
    if os.path.exists(destination):
        wb = openpyxl.load_workbook(destination, read_only=False)
        sheet = wb.active
        # task = "test CHECK"
        time_stamp = time.strftime('%I:%M%p')
        for i in range(1, 100):
            cell = 'B' + str(i)
            if (sheet[cell].value) == tasks:

                time_stamp_cell = 'E' + str(i)
                acr_write_cell = 'F' + str(i)
                sheet[acr_write_cell] = 'MM'
                if time_sent_on != '':  # checking if time is passed an an argument or not
                    # print("Success")
                    # print(sheet[cell].value)
                    sheet[time_stamp_cell] = str(time_sent_on)
                else:
                    sheet[time_stamp_cell] = str(time_stamp)

                wb.save(destination)
                print("Added timestamp as %s and operator signature as %s for %s" % (
                sheet[time_stamp_cell].value, sheet[acr_write_cell].value, tasks))
                break
    else:
        print("please check as todays runlog is unavailable to update")
