from write_to_runlog import write_to_runlog
import time
import os

def check_WSO_Files():
    filelocation = r'\\Stockval_serv\pam-export\export\WSO'
    WSO_Files = os.listdir(filelocation)
    count = 0
    for files in WSO_Files:
        if files.endswith('.CSV'):
            count += 1
            Time = time.strftime('%I:%M%p',time.localtime(os.path.getmtime(filelocation)))
    if count == 24:
        print('All WSO files are available at %s'%(Time))
        write_to_runlog('Check WSO Files - 24 Files',Time)
    else:
        print('All Files are not Available yet')

#check_WSO_Files()