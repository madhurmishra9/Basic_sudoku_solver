import win32com.client
from datetime import date
from write_to_runlog import write_to_runlog
from send_mail import send_mail

def Final_SWIFT_is_complete_check():
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")

    subject = 'Final SWIFT is complete'

    inbox = outlook.GetDefaultFolder(6)
    messages = inbox.Items
    message = messages.GetLast()
    while message:
        if message.senton.date() == date.today():
            if message.subject.strip() == subject.strip():
                try:
                    print('Final SWIFT has completed at %s' % (message.senton.strftime('%I:%M%p')))
                    # create_todays_runlog()
                    write_to_runlog("Final SWIFT is complete",message.senton.strftime('%I:%M%p'))
                    break
                except:
                    print(
                        "An exception Occured in Final SWIFT is complete check please contact Script Owner,before that make sure to check if runlog is open or in use by someone. Make sure to close it")
                    exit()
            else:
                message = messages.GetPrevious()
        else:
            if message.senton.date != date.today():
                #print('Swift email not received')
                message_body = 'Team please confirm the Final SWIFT completion'
                send_mail('mmishra@lordabbett.com','Final SWIFT not completed',message_body,)
                exit(-1)

#Final_SWIFT_is_complete_check()