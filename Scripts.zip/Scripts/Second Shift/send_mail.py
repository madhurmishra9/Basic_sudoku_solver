import win32com.client



def send_mail(TO = '',Subject='', body='', Attachment='No', attachment_path=''):
    # print('In send_mail')
    outlook = win32com.client.Dispatch('outlook.application')
    mail = outlook.CreateItem(0)
    mail.To = TO
    mail.Subject = Subject
    mail.Body = body
    # mail.HTMLBody = '<h2>HTML Message body</h2>' #this field is optional
    if Attachment == 'Yes':
        # To attach a file to the email (optional):
        attachment = attachment_path
        mail.Attachments.Add(attachment)

    mail.Send()
    return