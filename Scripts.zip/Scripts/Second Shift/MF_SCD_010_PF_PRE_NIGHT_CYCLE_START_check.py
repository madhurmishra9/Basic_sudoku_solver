import win32com.client
from datetime import date
from write_to_runlog import write_to_runlog

def MF_SCD_010_PF_PRE_NIGHT_CYCLE_START_check():
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")

    subject = 'Start and End Time for MF_SCD_010_PF_PRE_NIGHT_CYCLE_STARTCompleted Normally'

    inbox = outlook.GetDefaultFolder(6).Folders('Tidal')
    messages = inbox.Items
    message = messages.GetLast()
    while message:
        if message.senton.date() == date.today():
            if message.subject.strip() == subject.strip():
                try:
                    print('MF_SCD_010_PF_PRE_NIGHT_CYCLE_START has completed at %s' % (message.senton.strftime('%I:%M%p')))
                    # create_todays_runlog()
                    write_to_runlog("MF_SCD_010_PF_PRE_NIGHT_CYCLE_START (1)",message.senton.strftime('%I:%M%p'))
                    break
                except:
                    print(
                        "An exception Occured in MF_SCD_010_PF_PRE_NIGHT_CYCLE_START please contact Script Owner,before that make sure to check if runlog is open or in use by someone. Make sure to close it")
                    exit()
            else:
                message = messages.GetPrevious()
        else:
            break

#MF_SCD_010_PF_PRE_NIGHT_CYCLE_START_check()