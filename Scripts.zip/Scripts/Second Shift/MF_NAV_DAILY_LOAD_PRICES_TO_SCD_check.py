import win32com.client
from datetime import date
from write_to_runlog import write_to_runlog

def MF_NAV_DAILY_LOAD_PRICES_TO_SCD_check():
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")

    subject = 'Start and End Time for MF_NAV_DAILY_LOAD_PRICES_TO_SCDCompleted Normally'

    inbox = outlook.GetDefaultFolder(6).Folders('Tidal')
    messages = inbox.Items
    message = messages.GetLast()
    while message:
        if message.senton.date() == date.today():
            if message.subject.strip() == subject.strip():
                try:
                    print('MF_NAV_DAILY_LOAD_PRICES_TO_SCD has completed at %s' % (message.senton.strftime('%I:%M%p')))
                    # create_todays_runlog()
                    write_to_runlog("MF_NAV_DAILY_LOAD_PRICES_TO_SCD has to be done for SCD End of Day Complete to run.",message.senton.strftime('%I:%M%p'))
                    break
                except:
                    print(
                        "An exception Occured in MF_NAV_DAILY_LOAD_PRICES_TO_SCD check please contact Script Owner,before that make sure to check if runlog is open or in use by someone. Make sure to close it")
                    exit()
            else:
                message = messages.GetPrevious()
        else:
            break

#MF_NAV_DAILY_LOAD_PRICES_TO_SCD_check()