import openpyxl
import requests
import time
import os

def write_to_runlog(tasks='', time_sent_on=''):
    #print('In write_to_runlog')
    filename = 'Second Shift Run Log SimCorp ' + time.strftime('%m-%d-%Y') + '.xlsx'
    # source = r'L:\Desktop' + '\\' + str(time.strftime('%Y')) + '\\' + str(time.strftime('%m-%B')) + '\\' + 'First Shift' + '\\' + 'Run Log.xlsx'
    destination = r'L:\Desktop' + '\\' + str(time.strftime('%Y')) + '\\' + str(
        time.strftime('%#m- %B')) + '\\' + "Second Shift" + '\\' + filename
    if os.path.exists(destination):
        wb = openpyxl.load_workbook(destination, read_only=False)
        sheet = wb.active
        # task = "test CHECK"
        time_stamp = time.strftime('%I:%M%p')
        for i in range(1, 50):
            cell = 'B' + str(i)
            if (sheet[cell].value) == tasks:

                time_stamp_cell = 'D' + str(i)
                acr_write_cell = 'E' + str(i)
                sheet[acr_write_cell] = 'MM'
                if time_sent_on != '':  # checking if time is passed an an argument or not
                    # print("Success")
                    # print(sheet[cell].value)
                    sheet[time_stamp_cell] = str(time_sent_on)
                else:
                    sheet[time_stamp_cell] = str(time_stamp)

                wb.save(destination)
                print("Added timestamp as %s and operator signature as %s for %s" % (
                sheet[time_stamp_cell].value, sheet[acr_write_cell].value, tasks))
                break
    else:
        print("please check as todays runlog is unavailable to update")

def component_check(instance_data, instance_number):
    component_services = ['is_currently_running','notifications_enabled','active_service_checks_enabled','passive_service_checks_enabled','active_host_checks_enabled','passive_host_checks_enabled','event_handlers_enabled','flap_detection_enabled','process_performance_data','obsess_over_hosts','obsess_over_services']
    count = 0
    for i in range(0,len(component_services)):
        if instance_data[component_services[i]] != '1':
            print('Nagios instance %i Status is Not OK'%(instance_number))
            break
        else:
            #print('in here for instance %i'%instance_number)
            count+=1
    if count == len(component_services):
        print('All %s service for Nagios instance %s are OK'%(count,instance_number))
        write_to_runlog('Check all nagios instances for Monitoring Engine Process State. Should be Green')

def Nagios_status_check():

    #for Nagios instance 1
    req = requests.get(r'http://lxnagxip1-eopv/nagiosxi/api/v1/system/status?apikey=Zo2YrPHFnBtZUhjALvnZ90NRoSiQHuFWVWUnLC29pP8jmK97gv6oQSveKQ4IkZEA')
    #print(req.json())
    component_check(req.json(),1)

    #for Nagios instance 2
    req = requests.get(r'http://lxnagxip2-eopv/nagiosxi/api/v1/system/status?apikey=sGBcNl5nmdq7vRfVLE5D4YiIMXoKpbKUQC7TWrgCXKIMRWXSR2rUg4Sj0g3Jr4Uh')
    component_check(req.json(),2)

    #for Nagios instance 3
    # api url http://lxnagxip3-eopv/api/v1/system/status
    req = requests.get(r'http://lxnagxip3-eopv/nagiosxi/api/v1/system/status?apikey=4nEqnjmQm3VJt97rYpSWuRXKVPDoFhDYXeplA5rV7mUTPil4KtZuEdfA2ReW8QVm')
    component_check(req.json(),3)

    #for nagios instance 4
    req = requests.get(r'http://lxnagxip4-eopv/nagiosxi/api/v1/system/status?apikey=ucKRXtuUUDRvq3AY5Q0qpQC9A0UN5GeS9Y06LugF87qBp0PNQQuvW6XM79vr5NDd')
    component_check(req.json(),4)


Nagios_status_check()