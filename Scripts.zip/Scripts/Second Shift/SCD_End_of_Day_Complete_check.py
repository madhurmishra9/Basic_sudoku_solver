import win32com.client
from datetime import date
from write_to_runlog import write_to_runlog

def SCD_End_of_Day_Complete_check():
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")

    subject = 'SCD End of Day Complete - Please kick off the SCD night cycle process'

    inbox = outlook.GetDefaultFolder(6).Folders('End Of Day')
    messages = inbox.Items
    message = messages.GetLast()
    while message:
        if message.senton.date() == date.today():
            if message.subject.strip() == subject.strip():
                try:
                    print('SCD End of Day has completed at %s' % (message.senton.strftime('%I:%M%p')))
                    # create_todays_runlog()
                    write_to_runlog("RECEIVE EMAIL FROM ACCTING DEPT(SYSTEM ADMIN) TO START NIGHTLY WORK (SimCorp_NIGHT_CYCLE_BEGIN)    Extn # 8856  ",message.senton.strftime('%I:%M%p'))
                    write_to_runlog(
                        "SCD End of Day Complete (SCD_NIGHT_CYCLE (1))",
                        message.senton.strftime('%I:%M%p'))
                    break
                except:
                    print(
                        "An exception Occured in SCD End of Day Complete check please contact Script Owner,before that make sure to check if runlog is open or in use by someone. Make sure to close it")
                    exit()
            else:
                message = messages.GetPrevious()
        else:
            break

#SCD_End_of_Day_Complete_check()