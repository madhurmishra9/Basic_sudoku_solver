from write_to_runlog import write_to_runlog
import time
import os

def check_APL_Files_time():
    filelocation = r'\\ftpclu02-eopp\d$\InetPub\ftproot\APL'
    APL_Files = os.listdir(filelocation)
    count = 0
    for files in APL_Files:
        if files.endswith('.Z'):
            count += 1
            Time = time.strftime('%I:%M%p',time.localtime(os.path.getmtime(filelocation)))
    if count == 30:
        print('All APL files are available at %s'%(Time))
        write_to_runlog('Check APL Files - 30 Files',Time)
    else:
        print('All Files are not Available yet')


#check_APL_Files_time()