import win32com.client
from datetime import date
from send_mail import send_mail
from write_to_runlog import write_to_runlog

def FITS_is_done_with_Inforalgo_check():
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")

    subject = 'FITS is done with Inforalgo'

    inbox = outlook.GetDefaultFolder(6)
    messages = inbox.Items
    message = messages.GetLast()
    while message:
        if message.senton.date() == date.today():
            if message.subject.strip() == subject.strip():
                try:
                    print('FITS is done with Inforalgo has completed at %s' % (message.senton.strftime('%I:%M%p')))
                    # create_todays_runlog()
                    write_to_runlog("Email from Fixed Income Trade Support Team -(FITS has completed work in Inforalgo) Then you can Stop Inforalgo Extn: # 8857 ",message.senton.strftime('%I:%M%p'))
                    break
                except:
                    print(
                        "An exception Occured in FITS is done with Inforalgo check please contact Script Owner,before that make sure to check if runlog is open or in use by someone. Make sure to close it")
                    exit()
            else:
                message = messages.GetPrevious()
        else:
            if message.senton.date != date.today():
                #print('Swift email not received')
                message_body = 'Team please confirm whether FITS is done with Inforalgo'
                send_mail('mmishra@lordabbett.com','Not received FITS is done with Inforalgo',message_body)
                exit(-1)
            break

#FITS_is_done_with_Inforalgo_check()