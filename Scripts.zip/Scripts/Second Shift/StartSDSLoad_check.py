import win32com.client
from datetime import date
from write_to_runlog import write_to_runlog


def StartSDSLoad2_check():
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")

    subject = 'Start and End Time for StartSdsLoad2Completed Normally'

    inbox = outlook.GetDefaultFolder(6).Folders('Tidal')
    messages = inbox.Items
    message = messages.GetLast()
    while message:
        if message.senton.date() == date.today():
            if message.subject.strip() == subject.strip():
                try:
                    print('StartSDSLoad2 has completed at %s' % (message.senton.strftime('%I:%M%p')))
                    # create_todays_runlog()
                    write_to_runlog("Portfolio data Services\CRD\SDS\StartSDSLoad1/2 ",message.senton.strftime('%I:%M%p'))
                    break
                except:
                    print(
                        "An exception Occured in StartSDSLoad2 please contact Script Owner,before that make sure to check if runlog is open or in use by someone. Make sure to close it")
                    exit()
            else:
                message = messages.GetPrevious()
        else:
            break

#StartSDSLoad2_check()