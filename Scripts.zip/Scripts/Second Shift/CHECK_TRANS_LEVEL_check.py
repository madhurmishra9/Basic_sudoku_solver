import win32com.client
from datetime import date
from write_to_runlog import write_to_runlog

def CHECK_TRANS_LEVEL_check():
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")

    subject = 'Start and End Time for 095_CHECK_TRANS_LEVELCompleted Normally'

    inbox = outlook.GetDefaultFolder(6).Folders('Tidal')
    messages = inbox.Items
    message = messages.GetLast()
    while message:
        if message.senton.date() == date.today():
            if message.subject.strip() == subject.strip():
                try:
                    print('095_CHECK_TRANS_LEVEL has completed at %s' % (message.senton.strftime('%I:%M%p')))
                    write_to_runlog("Make sure this job is done.  095_CHECK_TRANS_LEVEL",message.senton.strftime('%I:%M%p'))
                    break
                except:
                    print(
                        "An exception Occured in 095_CHECK_TRANS_LEVEL please contact Script Owner,before that make sure to check if runlog is open or in use by someone. Make sure to close it")
                    exit()
            else:
                message = messages.GetPrevious()
        else:
            break

#CHECK_TRANS_LEVEL_check()