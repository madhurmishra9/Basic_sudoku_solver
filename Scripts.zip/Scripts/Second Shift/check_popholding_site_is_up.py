import requests as req
from write_to_runlog import write_to_runlog
import time



def check_popholding_site_accessibility():
    #print('In check_la_japan_site_accessibility')
    response = req.get("http://pdsbatp1-eiov/warehouse/cgi-bin/datafeeds.pl")
    # print(response.status_code)
    if response.status_code == 200:  # will check if response is 200 that means the website is accessible
        print("popholding site is up and running")
        write_to_runlog('Check POPHOLDING ON THE WEB  Benchmark Indexes', str(time.strftime('%I:%M%p')))
    else:
        print("Please check as the popholding site is unaccessible and have returned %d error" % (response.status_code))


#check_popholding_site_accessibility()