import win32com.client
from datetime import date
from write_to_runlog import write_to_runlog



def SHIFT_EXP_PMT_DT_check():
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")

    subject = 'SCD_POST_NIGHT_CYCLE completed start SDI group'

    inbox = outlook.GetDefaultFolder(6).Folders('Tidal')
    messages = inbox.Items
    message = messages.GetLast()
    while message:
        if message.senton.date() == date.today():
            if message.subject.strip() == subject.strip():
                try:
                    print('0310_SHIFT_EXP_PMT_DT has completed at %s' % (message.senton.strftime('%I:%M%p')))
                    # create_todays_runlog()
                    write_to_runlog('SCD_POST_NIGHT_CYCLE (0310_SHIFT_EXP_PMT_DT)',message.senton.strftime('%I:%M%p'))
                    write_to_runlog("When you get the email the 0310_SHIFT_EXP_PMT_DT is done. Free the SDI group",message.senton.strftime('%I:%M%p'))
                    break
                except:
                    print(
                        "An exception Occured in 0310_SHIFT_EXP_PMT_DT please contact Script Owner,before that make sure to check if runlog is open or in use by someone. Make sure to close it")
                    exit()
            else:
                message = messages.GetPrevious()
        else:
            break

#SHIFT_EXP_PMT_DT_check()